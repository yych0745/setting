IMPORTED_CXX_MODULES_INCLUDE_DIRECTORIES
----------------------------------------

.. versionadded:: 3.28

List of preprocessor include file search directories when compiling C++
modules for ``IMPORTED`` targets.

The value of this property is used by the generators to set the include
paths for the compiler.
